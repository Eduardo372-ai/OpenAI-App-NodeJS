const { app, BrowserWindow, screen } = require("electron")

let window;

const createWindow = () => {
    window = new BrowserWindow({
      width: 500,
      height: 500,
      x: screen.getPrimaryDisplay().workAreaSize.width - 500,
      y: 0,
      alwaysOnTop: true,
      transparent: false,
      frame: true,
  });
};

const loadOpenAI = () => {
  window.loadURL("https://chat.openai.com/chat")
}

app.on("ready", () => {
  createWindow();
  loadOpenAI();
})